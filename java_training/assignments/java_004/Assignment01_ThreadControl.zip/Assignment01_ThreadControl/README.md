ThreadControl

This was a collaberation assignment with Brian Cedillo.